// ProScholarsTools — Gemini API Proxy
// FREE: 1,500 requests/day — no credit card needed

const MAX_INPUT_CHARS = 4000;
const MODEL = 'gemini-2.0-flash';

module.exports = async function handler(req, res) {

  const origin = req.headers['origin'] || '';
  const allowed = ['proscholartools.com', 'localhost', '127.0.0.1', 'vercel.app'];
  const isAllowed = allowed.some(d => origin.includes(d));

  res.setHeader('Access-Control-Allow-Origin', isAllowed ? origin : 'https://proscholartools.com');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  let body;
  try { body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body; }
  catch { return res.status(400).json({ error: 'Invalid JSON' }); }

  const { messages } = body || {};
  if (!Array.isArray(messages) || !messages.length)
    return res.status(400).json({ error: 'Missing messages' });

  const inputText = messages.map(m => m.content || '').join('');
  if (inputText.length > MAX_INPUT_CHARS)
    return res.status(400).json({ error: 'Input too long' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'Service temporarily unavailable.' });

  try {
    const contents = messages.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

    const resp = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents,
          generationConfig: { maxOutputTokens: 1200, temperature: 0.7 }
        })
      }
    );

    const data = await resp.json();
    if (!resp.ok) return res.status(resp.status).json({ error: 'AI service error. Try again.' });

    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    if (!text) return res.status(500).json({ error: 'No response. Try again.' });

    return res.status(200).json({
      content: [{ type: 'text', text }],
      _meta: { model: MODEL, tier: 'free' }
    });

  } catch (err) {
    return res.status(500).json({ error: 'Server error. Try again.' });
  }
};
